//
//  Channelize_API.h
//  Channelize-API
//
//  Created by Apple on 12/27/18.
//  Copyright © 2018 Channelize. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Channelize_API.
FOUNDATION_EXPORT double Channelize_APIVersionNumber;

//! Project version string for Channelize_API.
FOUNDATION_EXPORT const unsigned char Channelize_APIVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Channelize_API/PublicHeader.h>


