//
//  Channelize.h
//  Channelize
//
//  Created by bigstep on 21/07/17.
//  Copyright © 2017 bigstep. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Channelize.
FOUNDATION_EXPORT double ChannelizeVersionNumber;

//! Project version string for Channelize.
FOUNDATION_EXPORT const unsigned char ChannelizeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Channelize/PublicHeader.h>


