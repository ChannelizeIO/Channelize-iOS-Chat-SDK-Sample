//
//  Channelizeh
//  ChannelizeAPI
//
//  Created by Ashish-BigStep on 3/25/20.
//  Copyright © 2020 Channelize. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Channelize
FOUNDATION_EXPORT double ChannelizeAPIVersionNumber;

//! Project version string for Channelize
FOUNDATION_EXPORT const unsigned char ChannelizeAPIVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ChannelizeAPI/PublicHeader.h>


